import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OBJLoader } from 'https://unpkg.com/three@0.160.0/examples/jsm/loaders/OBJLoader.js';
import { MTLLoader } from 'https://unpkg.com/three@0.160.0/examples/jsm/loaders/MTLLoader.js';

const MODEL_DIR = '../assets/models/';
const clock = new THREE.Clock();
const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x070b14, 18, 34);

const isCoarsePointer = window.matchMedia('(hover: none) and (pointer: coarse)').matches;

const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 10.2, 9.7);
camera.lookAt(0, 0.2, -5.4);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, isCoarsePointer ? 1.5 : 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.body.appendChild(renderer.domElement);

const overlay = document.getElementById('overlay');
const scoreEl = document.getElementById('score');
const livesEl = document.getElementById('lives');
const waveEl = document.getElementById('wave');
const startButton = document.getElementById('startButton');
const touchPad = document.getElementById('touch-pad');
const fireButton = document.getElementById('fire-button');

const ambient = new THREE.AmbientLight(0xffffff, 1.3);
scene.add(ambient);
const dir = new THREE.DirectionalLight(0xb8dcff, 2.2);
dir.position.set(3, 8, 8);
scene.add(dir);
const rim = new THREE.DirectionalLight(0xff77aa, 0.9);
rim.position.set(-6, 4, -8);
scene.add(rim);

const field = new THREE.Mesh(
  new THREE.PlaneGeometry(24, 30),
  new THREE.MeshPhongMaterial({
    color: 0x09111f,
    emissive: 0x050812,
    shininess: 3,
    transparent: true,
    opacity: 0.97,
  })
);
field.rotation.x = -Math.PI / 2;
field.position.set(0, -0.45, -6);
scene.add(field);

const grid = new THREE.GridHelper(24, 24, 0x2f76ff, 0x14264f);
grid.position.set(0, -0.43, -6);
grid.material.opacity = 0.14;
grid.material.transparent = true;
scene.add(grid);

createStarfield();

const keys = new Set();
let canStartFromOverlay = true;
const touch = {
  active: false,
  moveX: 0,
  autoFire: false,
  boostFire: false,
  pointerId: null,
};

function prevent(e) {
  e.preventDefault();
}

window.addEventListener('keydown', (e) => {
  if (['ArrowLeft','ArrowRight','Space','KeyA','KeyD','KeyR'].includes(e.code)) e.preventDefault();
  keys.add(e.code);
  if (overlay.classList.contains('show') && e.code === 'Space' && canStartFromOverlay) {
    canStartFromOverlay = false;
    startGame();
  }
  if (e.code === 'KeyR') {
    resetGame();
    if (overlay.classList.contains('show')) startGame();
  }
});
window.addEventListener('keyup', (e) => keys.delete(e.code));
window.addEventListener('resize', onResize);
document.addEventListener('touchmove', prevent, { passive: false });
document.addEventListener('gesturestart', prevent, { passive: false });

startButton?.addEventListener('click', () => {
  canStartFromOverlay = false;
  startGame();
});

if (touchPad) {
  const handlePad = (clientX) => {
    const rect = touchPad.getBoundingClientRect();
    const normalized = ((clientX - rect.left) / rect.width) * 2 - 1;
    touch.moveX = THREE.MathUtils.clamp(normalized, -1, 1);
  };

  touchPad.addEventListener('pointerdown', (e) => {
    touch.active = true;
    touch.pointerId = e.pointerId;
    handlePad(e.clientX);
    touchPad.setPointerCapture?.(e.pointerId);
  });

  touchPad.addEventListener('pointermove', (e) => {
    if (!touch.active || touch.pointerId !== e.pointerId) return;
    handlePad(e.clientX);
  });

  const endTouch = (e) => {
    if (touch.pointerId !== e.pointerId) return;
    touch.active = false;
    touch.moveX = 0;
    touch.pointerId = null;
  };
  touchPad.addEventListener('pointerup', endTouch);
  touchPad.addEventListener('pointercancel', endTouch);
}

if (fireButton) {
  fireButton.addEventListener('pointerdown', (e) => {
    fireButton.setPointerCapture?.(e.pointerId);
    touch.boostFire = true;
  });
  const stopFire = () => { touch.boostFire = false; };
  fireButton.addEventListener('pointerup', stopFire);
  fireButton.addEventListener('pointercancel', stopFire);
}

const state = {
  started: false,
  gameOver: false,
  score: 0,
  lives: 3,
  wave: 1,
  shootCooldown: 0,
  enemyShootTimer: 0,
  diveTimer: 2.2,
  enemies: [],
  playerBullets: [],
  enemyBullets: [],
  effects: [],
  formationCenterX: 0,
  formationDir: 1,
  formationPhase: 0,
};

const assetManager = new AssetManager();
await assetManager.loadAll();

const player = {
  speed: isCoarsePointer ? 10.5 : 8.8,
  mesh: assetManager.getClone('ship2', 0x73c8ff),
  radius: 0.52,
  flash: 0,
};
player.mesh.position.set(0, 0, 2.9);
player.mesh.rotation.y = Math.PI;
player.mesh.scale.multiplyScalar(0.65);
scene.add(player.mesh);

spawnWave();
updateHud();
animate();

function startGame() {
  overlay.classList.remove('show');
  state.started = true;
  state.gameOver = false;
  touch.autoFire = isCoarsePointer;
}

function resetGame() {
  clearAll(state.playerBullets);
  clearAll(state.enemyBullets);
  clearAll(state.effects);
  clearAll(state.enemies);
  state.score = 0;
  state.lives = 3;
  state.wave = 1;
  state.shootCooldown = 0;
  state.enemyShootTimer = 0;
  state.diveTimer = 2.2;
  state.formationCenterX = 0;
  state.formationDir = 1;
  state.formationPhase = 0;
  state.gameOver = false;
  player.mesh.visible = true;
  player.mesh.position.set(0, 0, 2.9);
  player.flash = 0;
  spawnWave();
  updateHud();
}

function spawnWave() {
  clearAll(state.enemies);
  const rows = 3 + Math.min(state.wave - 1, 1);
  const cols = 6;
  const startX = -4.2;
  const spacingX = 1.65;
  const spacingZ = 1.2;
  const topZ = -11.4;
  const types = ['ship8', 'ship6', 'ship7', 'tie-fighter'];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const type = types[Math.min(types.length - 1, row)];
      const tint = [0xff8fb8, 0xffd670, 0xb6ff89, 0xd6a3ff][Math.min(3, row)];
      const mesh = assetManager.getClone(type, tint);
      const enemy = {
        type,
        row,
        col,
        radius: type === 'ship8' ? 0.34 : 0.46,
        mesh,
        attackMode: null,
        attackT: 0,
        homeOffsetX: startX + col * spacingX,
        homeOffsetZ: topZ + row * spacingZ,
      };
      mesh.position.set(enemy.homeOffsetX, 0, enemy.homeOffsetZ);
      mesh.rotation.y = Math.PI;
      mesh.scale.multiplyScalar(type === 'ship8' ? 0.95 : 0.7);
      scene.add(mesh);
      state.enemies.push(enemy);
    }
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.033);
  state.formationPhase += dt;
  if (state.started && !state.gameOver && !showingRotateNotice()) update(dt);
  renderPlayerFeedback(dt);
  renderer.render(scene, camera);
}

function showingRotateNotice() {
  return isCoarsePointer && window.innerHeight > window.innerWidth;
}

function update(dt) {
  state.shootCooldown -= dt;
  state.enemyShootTimer -= dt;
  state.diveTimer -= dt;

  updatePlayer(dt);
  updateFormation(dt);
  updateBullets(state.playerBullets, dt, -14, 1);
  updateBullets(state.enemyBullets, dt, 7, -1);
  updateEffects(dt);
  maybeEnemyShoot();
  maybeStartDive();
  handleCollisions();

  if (state.enemies.length === 0) {
    state.wave += 1;
    spawnWave();
    updateHud();
  }
}

function updatePlayer(dt) {
  let move = 0;
  if (keys.has('ArrowLeft') || keys.has('KeyA')) move -= 1;
  if (keys.has('ArrowRight') || keys.has('KeyD')) move += 1;
  if (isCoarsePointer) move += touch.moveX;
  move = THREE.MathUtils.clamp(move, -1, 1);

  player.mesh.position.x += move * player.speed * dt;
  player.mesh.position.x = THREE.MathUtils.clamp(player.mesh.position.x, -5.8, 5.8);
  player.mesh.rotation.z = THREE.MathUtils.lerp(player.mesh.rotation.z, -move * 0.28, 8 * dt);

  const mobileFireRate = touch.boostFire ? 0.09 : 0.18;
  const shouldFire = keys.has('Space') || (isCoarsePointer && touch.autoFire);
  if (shouldFire && state.shootCooldown <= 0) {
    firePlayerBullet();
    state.shootCooldown = isCoarsePointer ? mobileFireRate : 0.22;
  }
}

function updateFormation(dt) {
  const speed = 1.2 + (state.wave - 1) * 0.12;
  state.formationCenterX += state.formationDir * speed * dt;
  if (state.formationCenterX > 2.8) state.formationDir = -1;
  if (state.formationCenterX < -2.8) state.formationDir = 1;

  for (const enemy of state.enemies) {
    if (!enemy.attackMode) {
      const sway = Math.sin(state.formationPhase * 2 + enemy.row * 0.45 + enemy.col * 0.28) * 0.14;
      enemy.mesh.position.x = enemy.homeOffsetX + state.formationCenterX + sway;
      enemy.mesh.position.z = enemy.homeOffsetZ + Math.sin(state.formationPhase + enemy.col) * 0.04;
      enemy.mesh.rotation.z = Math.sin(state.formationPhase * 3 + enemy.col) * 0.06;
      enemy.mesh.rotation.x = Math.sin(state.formationPhase * 4 + enemy.row) * 0.05;
    } else {
      enemy.attackT += dt;
      const t = enemy.attackT;
      if (enemy.attackMode === 'dive') {
        enemy.mesh.position.x = enemy.attackStart.x + Math.sin(t * 6 + enemy.attackSeed) * 1.2 + enemy.attackCurve * t;
        enemy.mesh.position.z = enemy.attackStart.z + t * 6.5;
        enemy.mesh.rotation.z = Math.sin(t * 7) * 0.4;
        enemy.mesh.rotation.x = 0.4;
        if (enemy.mesh.position.z > 3.8) {
          enemy.attackMode = 'return';
          enemy.attackT = 0;
          enemy.returnStart = enemy.mesh.position.clone();
        }
      } else if (enemy.attackMode === 'return') {
        const lerp = Math.min(1, t / 1.3);
        const targetX = enemy.homeOffsetX + state.formationCenterX;
        const targetZ = enemy.homeOffsetZ;
        enemy.mesh.position.x = THREE.MathUtils.lerp(enemy.returnStart.x, targetX, lerp);
        enemy.mesh.position.z = THREE.MathUtils.lerp(enemy.returnStart.z, targetZ, lerp);
        enemy.mesh.rotation.z *= 0.92;
        enemy.mesh.rotation.x *= 0.9;
        if (lerp >= 1) enemy.attackMode = null;
      }
    }
  }
}

function updateBullets(arr, dt, offscreenZ, dir) {
  for (let i = arr.length - 1; i >= 0; i--) {
    const bullet = arr[i];
    bullet.mesh.position.z += bullet.speed * dt;
    bullet.mesh.position.x += (bullet.vx || 0) * dt;
    bullet.life -= dt;
    bullet.mesh.rotation.z += dt * 14;
    if ((dir > 0 && bullet.mesh.position.z > offscreenZ) || (dir < 0 && bullet.mesh.position.z < offscreenZ) || bullet.life <= 0) {
      scene.remove(bullet.mesh);
      arr.splice(i, 1);
    }
  }
}

function updateEffects(dt) {
  for (let i = state.effects.length - 1; i >= 0; i--) {
    const effect = state.effects[i];
    effect.life -= dt;
    effect.mesh.scale.addScalar(dt * 2.4);
    effect.mesh.material.opacity = Math.max(0, effect.life / effect.maxLife);
    effect.mesh.rotation.y += dt * 2.5;
    if (effect.life <= 0) {
      scene.remove(effect.mesh);
      state.effects.splice(i, 1);
    }
  }
}

function maybeEnemyShoot() {
  const alive = state.enemies.filter((e) => e.mesh.visible);
  if (alive.length === 0) return;
  const interval = Math.max(0.35, 1.18 - state.wave * 0.06);
  if (state.enemyShootTimer > 0) return;
  const shooter = alive[Math.floor(Math.random() * alive.length)];
  const bullet = createBullet(0xff5a8f, 0.11, 0.55);
  bullet.position.copy(shooter.mesh.position);
  bullet.position.z += 0.45;
  bullet.position.y = 0.05;
  const dx = (player.mesh.position.x - shooter.mesh.position.x) * 0.35;
  scene.add(bullet);
  state.enemyBullets.push({ mesh: bullet, speed: 6.6 + state.wave * 0.22, vx: dx, radius: 0.17, life: 3.4 });
  state.enemyShootTimer = interval;
}

function maybeStartDive() {
  if (state.diveTimer > 0) return;
  const formationEnemies = state.enemies.filter((e) => !e.attackMode);
  if (formationEnemies.length) {
    const enemy = formationEnemies[Math.floor(Math.random() * formationEnemies.length)];
    enemy.attackMode = 'dive';
    enemy.attackT = 0;
    enemy.attackStart = enemy.mesh.position.clone();
    enemy.attackCurve = (Math.random() - 0.5) * 2.2;
    enemy.attackSeed = Math.random() * Math.PI * 2;
  }
  state.diveTimer = Math.max(1.4, 3.4 - state.wave * 0.14);
}

function handleCollisions() {
  for (let i = state.playerBullets.length - 1; i >= 0; i--) {
    const bullet = state.playerBullets[i];
    let hit = false;
    for (let j = state.enemies.length - 1; j >= 0; j--) {
      const enemy = state.enemies[j];
      if (distance2D(bullet.mesh.position, enemy.mesh.position) < bullet.radius + enemy.radius) {
        createExplosion(enemy.mesh.position, 0xffd27a);
        scene.remove(enemy.mesh);
        state.enemies.splice(j, 1);
        scene.remove(bullet.mesh);
        state.playerBullets.splice(i, 1);
        state.score += enemy.row >= 3 ? 250 : 100 + (enemy.row * 50);
        updateHud();
        hit = true;
        break;
      }
    }
    if (hit) continue;
  }

  if (!player.mesh.visible) return;

  for (let i = state.enemyBullets.length - 1; i >= 0; i--) {
    const bullet = state.enemyBullets[i];
    if (distance2D(bullet.mesh.position, player.mesh.position) < bullet.radius + player.radius) {
      scene.remove(bullet.mesh);
      state.enemyBullets.splice(i, 1);
      damagePlayer();
      return;
    }
  }

  for (const enemy of state.enemies) {
    if (distance2D(enemy.mesh.position, player.mesh.position) < enemy.radius + player.radius * 1.18) {
      createExplosion(enemy.mesh.position, 0xff7a7a);
      scene.remove(enemy.mesh);
      state.enemies = state.enemies.filter((e) => e !== enemy);
      damagePlayer();
      return;
    }
  }
}

function damagePlayer() {
  createExplosion(player.mesh.position, 0x71b8ff);
  state.lives -= 1;
  updateHud();
  if (state.lives <= 0) {
    player.mesh.visible = false;
    state.gameOver = true;
    state.started = false;
    overlay.querySelector('.panel').innerHTML = `
      <h1>GAME OVER</h1>
      <p>Your final score: <strong>${state.score}</strong></p>
      <p class="desktop-only small">Press <strong>R</strong> to restart.</p>
      <p class="mobile-only small">Tap below to restart.</p>
      <button id="restartMobile" class="cta mobile-only">RESTART</button>
    `;
    overlay.classList.add('show');
    document.getElementById('restartMobile')?.addEventListener('click', () => {
      resetGame();
      startGame();
    }, { once: true });
    canStartFromOverlay = false;
    return;
  }
  player.flash = 1;
  player.mesh.position.set(0, 0, 2.9);
  clearAll(state.enemyBullets);
}

function renderPlayerFeedback(dt) {
  if (player.flash > 0) {
    player.flash -= dt * 1.9;
    player.mesh.visible = Math.floor(player.flash * 14) % 2 === 0;
    if (player.flash <= 0) player.mesh.visible = true;
  }
}

function firePlayerBullet() {
  const bullet = createBullet(0x8be7ff, 0.09, 0.8);
  bullet.position.copy(player.mesh.position);
  bullet.position.z -= 0.7;
  bullet.position.y = 0.04;
  scene.add(bullet);
  state.playerBullets.push({ mesh: bullet, speed: -12.5, radius: 0.14, life: 2.2 });
}

function createBullet(color, radius, length) {
  const geo = new THREE.CapsuleGeometry(radius, length, 4, 8);
  const mat = new THREE.MeshBasicMaterial({ color });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = Math.PI / 2;
  return mesh;
}

function createExplosion(position, color) {
  const mesh = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.22, 1),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95 })
  );
  mesh.position.copy(position);
  scene.add(mesh);
  state.effects.push({ mesh, life: 0.38, maxLife: 0.38 });
}

function updateHud() {
  scoreEl.textContent = state.score;
  livesEl.textContent = state.lives;
  waveEl.textContent = state.wave;
}

function distance2D(a, b) {
  const dx = a.x - b.x;
  const dz = a.z - b.z;
  return Math.hypot(dx, dz);
}

function clearAll(arr) {
  while (arr.length) {
    const item = arr.pop();
    if (item.mesh) scene.remove(item.mesh);
    else scene.remove(item);
  }
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, isCoarsePointer ? 1.5 : 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function createStarfield() {
  const count = isCoarsePointer ? 520 : 900;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    positions[i * 3 + 0] = (Math.random() - 0.5) * 36;
    positions[i * 3 + 1] = Math.random() * 18;
    positions[i * 3 + 2] = -Math.random() * 40;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const points = new THREE.Points(
    geo,
    new THREE.PointsMaterial({ color: 0xbfd8ff, size: 0.045, transparent: true, opacity: 0.9 })
  );
  scene.add(points);
}

function tintModel(root, color) {
  root.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = false;
      child.receiveShadow = false;
      const source = Array.isArray(child.material) ? child.material[0] : child.material;
      const mat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.42,
        metalness: 0.18,
        emissive: new THREE.Color(color).multiplyScalar(0.08),
      });
      if (source?.name?.toLowerCase().includes('glass')) mat.emissiveIntensity = 0.45;
      child.material = mat;
    }
  });
}

class AssetManager {
  constructor() {
    this.cache = new Map();
    this.mtlLoader = new MTLLoader();
    this.objLoader = new OBJLoader();
    this.configs = {
      ship2: { scale: 0.56 },
      ship6: { scale: 0.44 },
      ship7: { scale: 0.48 },
      ship8: { scale: 0.9 },
      'tie-fighter': { scale: 0.25 },
    };
  }

  async loadAll() {
    const ids = ['ship2', 'ship6', 'ship7', 'ship8', 'tie-fighter'];
    await Promise.all(ids.map((id) => this.loadModel(id)));
  }

  async loadModel(id) {
    const mtlPath = `${MODEL_DIR}${id}.mtl`;
    const objPath = `${MODEL_DIR}${id}.obj`;
    return new Promise((resolve, reject) => {
      this.mtlLoader.load(mtlPath, (materials) => {
        materials.preload();
        this.objLoader.setMaterials(materials);
        this.objLoader.load(objPath, (obj) => {
          obj.traverse((child) => {
            if (child.isMesh) {
              child.geometry.computeBoundingSphere();
              child.geometry.computeVertexNormals();
            }
          });
          const s = this.configs[id]?.scale ?? 0.5;
          obj.scale.setScalar(s);
          this.cache.set(id, obj);
          resolve(obj);
        }, undefined, reject);
      }, undefined, reject);
    });
  }

  getClone(id, tint = 0xffffff) {
    const original = this.cache.get(id);
    const clone = original.clone(true);
    tintModel(clone, tint);
    return clone;
  }
}
